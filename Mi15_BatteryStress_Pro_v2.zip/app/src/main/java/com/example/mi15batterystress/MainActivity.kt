package com.example.mi15batterystress

import android.app.Activity
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val h=Handler(Looper.getMainLooper()); private var run=false
    private var start=0L; private var startLevel=0; private var peak=0.0
    private lateinit var status:TextView; private lateinit var metrics:TextView; private lateinit var bar:ProgressBar
    private lateinit var log:TextView; private lateinit var btn:Button; private var mode="混合"
    private val history=mutableListOf<String>()
    private val tick=object:Runnable{override fun run(){if(!run)return; sample(); h.postDelayed(this,1000)}}

    override fun onCreate(b:Bundle?){super.onCreate(b)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,28,24,24)}
        val sv=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val title=TextView(this).apply{text="小米 15 电池压力测试 Pro";textSize=24f}
        status=TextView(this).apply{textSize=15f;setPadding(0,12,0,12)}
        metrics=TextView(this).apply{textSize=16f}
        bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100}
        val modes=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("轻度","标准","混合"))}
        modes.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){mode=arrayOf("轻度","标准","混合")[pos]}
        }
        btn=Button(this).apply{text="开始测试";setOnClickListener{if(run)stop("手动停止")else start()}}
        log=TextView(this).apply{textSize=13f;setPadding(0,16,0,0)}
        box.addView(title);box.addView(status);box.addView(metrics);box.addView(bar)
        box.addView(TextView(this).apply{text="测试模式";setPadding(0,18,0,4)});box.addView(modes);box.addView(btn)
        box.addView(log);sv.addView(box);root.addView(sv);setContentView(root);sample()
    }
    private fun batt():Triple<Int,Double,Int>{
        val bm=getSystemService(BATTERY_SERVICE) as BatteryManager
        val i=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0,100)
        val x=registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t=(x?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)?:0)/10.0
        val c=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        return Triple(i,t,c)
    }
    private fun sample(){
        val(a,t,c)=batt();peak=max(peak,t);bar.progress=a
        val sec=if(run)(System.currentTimeMillis()-start)/1000 else 0
        metrics.text=String.format(Locale.US,"电量：%d%%\\n温度：%.1f °C\\n电流：%d mA\\n最高温度：%.1f °C\\n运行时间：%02d:%02d",a,t,c/1000,peak,sec/60,sec%60)
        status.text=if(run)"测试中 · $mode · 42°C降载提示 / 45°C停止 / ≤20%停止" else "待机 · 安全保护开启"
        if(run){history.add(String.format(Locale.US,"%02d:%02d  %d%%  %.1f°C  %dmA",sec/60,sec%60,a,t,c/1000));log.text="最近数据：\\n"+history.takeLast(12).joinToString("\\n")
            if(t>=45)stop("达到45°C，已强制停止") else if(t>=42)status.text="温度≥42°C：建议立即停止并让手机自然降温" else if(a<=20)stop("电量≤20%，已停止")
            if(sec>=1200)stop("20分钟测试完成")
        }
    }
    private fun start(){val(a,t,_)=batt();if(a<=20||t>=42){status.text="当前条件不适合开始测试";return};run=true;start=System.currentTimeMillis();startLevel=a;peak=t;history.clear();btn.text="停止测试";h.post(tick)}
    private fun stop(reason:String){run=false;h.removeCallbacks(tick);val(a,_,_)=batt();btn.text="开始测试";status.text="$reason · 本次电量变化 ${max(0,startLevel-a)}%";sample()}
    override fun onDestroy(){h.removeCallbacksAndMessages(null);super.onDestroy()}
}
